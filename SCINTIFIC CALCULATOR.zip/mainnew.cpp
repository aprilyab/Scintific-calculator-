#include <cmath> // Include the cmath library for mathematical functions
#include <iostream>
#include <limits>
using namespace std;
#include "new.h" // Include the user-defined header file for additional functions

int main() {
  int type_of_operation; // Variable to store user's choice of operation

  // Display the calculator menu
  cout << "======================== Calculator Menu ========================"
       << endl;
  cout << "What type of operation do you want? Choose from the following "
          "options: "
       << endl;
  displayMenu();
  bool running = true;
  // Input the user's choice
  while (running) {
    cout << "Enter the number corresponding to your choice (21 for menu): ";
    cin >> type_of_operation;

    double a; // Variable to store input number
    double b; // Variable to store input number

    // Switch case to execute the operation based on user's choice
    switch (type_of_operation) {

    case 0:
      // Exit the program
      cout << "Thank you for using the calculator.\n";
      exit(0); // Exit the program

    case 1:
      // Addition operation
      cout << "enter two numbers :  ";
      cin >> a >> b;
      cout << addition(a, b) << endl; // Call the addition function
      break;

    case 2:
      // Subtraction operation
      cout << "enter two numbers:  ";
      cin >> a >> b;
      cout << difference(a, b) << endl; // Call the difference function
      break;

    case 3:
      // Multiplication operation
      cout << "enter two numbers:  ";
      cin >> a >> b;
      cout << multiplication(a, b) << endl; // Call the multiplication function
      break;

    case 4:
      // Division operation
      cout << "enter dividend and divisor:  ";
      cin >> a >> b;
      cout << division(a, b) << endl; // Call the division function
      break;

    case 5:
      // Exponential operation (a^b)
      cout << "enter the base and the exponent:  ";
      cin >> a >> b;
      cout << Exponential(a, b) << endl; // Call the power function
      break;

    case 6:
      // Square Root operation
      cout << "enter a number:  " << endl;
      cin >> a;
      cout << square_root(a) << endl; // Call the square root function
      break;

    case 7:
      // Sine operation (sin)
      cout << "enter a value of angle in degree:  " << endl;
      cin >> a;
      a = a / 57.3;            // Convert angle from degrees to radians
      cout << sine(a) << endl; // Call the sine function
      break;

    case 8:
      // Cosine operation (cos)
      cout << "enter a value of angle in degree:  " << endl;
      cin >> a;
      a = a / 57.3;              // Convert angle from degrees to radians
      cout << cosine(a) << endl; // Call the cosine function
      break;

    case 9:
      // Tangent operation (tan)
      cout << "enter a value of angle in degree:  " << endl;
      cin >> a;
      a = a / 57.3;               // Convert angle from degrees to radians
      cout << tangent(a) << endl; // Call the tangent function
      break;

    case 10:
      // Cosecant operation (csc)
      cout << "enter a value of angle in degree:  " << endl;
      cin >> a;
      a = a / 57.3;                // Convert angle from degrees to radians
      cout << cosecant(a) << endl; // Call the cosecant function
      break;

    case 11:
      // Secant operation (sec)
      cout << "enter a value of angle in degree:  " << endl;
      cin >> a;
      a = a / 57.3;              // Convert angle from degrees to radians
      cout << secant(a) << endl; // Call the secant function
      break;

    case 12:
      // Cotangent operation (cot)
      cout << "enter a value of angle in degree:  " << endl;
      cin >> a;
      a = a / 57.3;                 // Convert angle from degrees to radians
      cout << cotangent(a) << endl; // Call the cotangent function
      break;

    case 13:
      // Inverse Sine operation (arcsin)
      cout << "enter a value:  " << endl;
      cin >> a;
      cout << arcsine(a) << endl; // Call the arcsine function
      break;

    case 14:
      // Inverse Cosine operation (arccos)
      cout << "enter a value:  " << endl;
      cin >> a;
      cout << arccosine(a) << endl; // Call the arccosine function
      break;

    case 15:
      // Inverse Tangent operation (arctan)
      cout << "enter a value:  " << endl;
      cin >> a;
      cout << arctangent(a) << endl; // Call the arctangent function
      break;

    case 19:
      // Logarithm operation (log)
      cout << "enter the number and base of logarithm:  ";
      cin >> a >> b;
      cout << logarithmic(a, b) << endl; // Call the logarithmic function
      break;

    case 20:
      // Natural Logarithm operation (ln)
      cout << "enter a number:  ";
      cin >> a;
      cout << natural_logarithmic(a)
           << endl; // Call the natural logarithmic function
      break;
    case 21:
      displayMenu();
      break;
    default:
      // Invalid input handling
      cerr << "invalid input: your input do not match with any given options "
              "of operations  "
           << endl; // Error message if the input doesn't match any case
      cin.clear();
      cin.ignore(numeric_limits<int>::max(), '\n'); // clears the input stream
      break;
    }
  }

  return 0;
}
