#pragma once // to ensure a file is only included once, preventing errors caused
             // by multiple inclusions

void displayMenu();
// Declaration of addition function
double addition(double a, double b);

// Declaration of difference function (subtraction)
double difference(double a, double b);

// Declaration of division function
double division(double a, double b);

// Declaration of multiplication function
double multiplication(double a, double b);

// Declaration of power function
double Exponential(double a, double b);

// Declaration of square root function
double square_root(double a);

// Declaration of sine function
double sine(double a);

// Declaration of cosine function
double cosine(double a);

// Declaration of tangent function
double tangent(double a);

// Declaration of cosecant function
double cosecant(double a);

// Declaration of secant function
double secant(double a);

// Declaration of cotangent function
double cotangent(double a);

// Declaration of arcsine function (inverse sine)
double arcsine(double a);

// Declaration of arccosine function (inverse cosine)
double arccosine(double a);

// Declaration of arctangent function (inverse tangent)
double arctangent(double a);

// Declaration of logarithmic function with a given base
double logarithmic(double a, double b);

// Declaration of natural logarithmic function (base e)
double natural_logarithmic(double a);
