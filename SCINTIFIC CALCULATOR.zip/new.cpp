#include "new.h" // Include the user-defined header file for additional functions
#include <cmath> // Include the cmath library for mathematical functions
#include <iomanip>
#include <iostream>
using namespace std;

void displayMenu() {
  cout << left;
  cout << "======================== Calculator Menu ========================"
       << endl;
  cout << "What type of operation do you want? Choose from the following "
          "options: "
       << endl;
  cout << setw(20) << "1.  Addition" << setw(20) << "2.  Subtraction"
       << setw(20) << "3.  Multiplication" << setw(20) << "4.  Division"
       << endl;
  cout << setw(20) << "5.  Exponential" << setw(20) << "6.  Square Root"
       << setw(20) << "7.  Sine (sin)" << setw(20) << "8.  Cosine (cos)"
       << endl;
  cout << setw(20) << "9.  Tangent (tan)" << setw(20) << "10. Cosecant (csc)"
       << setw(20) << "11. Secant (sec)" << setw(20) << "12. Cotangent (cot)"
       << endl;
  cout << setw(20) << "13. arcsin" << setw(20) << "14. arccos" << setw(20)
       << "15. arctan" << setw(20) << "16. arccsc" << endl;
  cout << setw(20) << "17. arcsec" << setw(20) << "18. arccot" << setw(20)
       << "19. Logarithm (log)" << setw(20) << "20. Natural Logarithm (ln)"
       << endl;
  cout << right << setw(40) << "0. Exit" << endl;
}
// Function for addition of two numbers
double addition(double a, double b) { return a + b; }

// Function for subtraction of two numbers
double difference(double a, double b) { return a - b; }

// Function for multiplication of two numbers
double multiplication(double a, double b) { return a * b; }

// Function for division of two numbers, includes error handling for division by
// zero
double division(double a, double b) {
  try {
    if (b == 0) {
      throw runtime_error("division by zero");
    }
    return a / b;
  } catch (const runtime_error &e) {
    cout << "Error: division by zero is not allowed." << endl;
  }
  return 1; // Return 1 as a fallback value
}

// Function for calculating the power of a number
double Exponential(double a, double b) { return pow(a, b); }

// Function for calculating the square root of a number
double square_root(double a) {
  if (a >= 0) {
    return sqrt(a);
  } else {
    cout << "Invalid input: negative numbers cannot have square roots." << endl;
  }
  return 1; // Return 1 as a fallback value for invalid input
}

// Function for calculating sine of an angle (in radians)
double sine(double a) { return sin(a); }

// Function for calculating cosine of an angle (in radians)
double cosine(double a) { return cos(a); }

// Function for calculating tangent of an angle (in radians)
double tangent(double a) { return tan(a); }

// Function for calculating cosecant of an angle (in radians)
double cosecant(double a) {
  if (sin(a) != 0) {
    return 1 / sin(a);
  } else {
    cout << "Invalid input: Cosecant is undefined for this value." << endl;
  }
  return 1; // Return 1 as a fallback value
}

// Function for calculating secant of an angle (in radians)
double secant(double a) {
  if (cos(a) != 0) {
    return 1 / cos(a);
  } else {
    cout << "Invalid input: Secant is undefined for this value." << endl;
  }
  return 1; // Return 1 as a fallback value
}

// Function for calculating cotangent of an angle (in radians)
double cotangent(double a) {
  if (tan(a) != 0) {
    return 1 / tan(a);
  } else {
    cout << "Invalid input: Cotangent is undefined for this value." << endl;
  }
  return 1; // Return 1 as a fallback value
}

// Function for calculating the logarithm of a number with a given base
double logarithmic(double a, double b) {
  if (a > 0 && b > 0 && b != 1) {
    return log(a) / log(b);
  } else {
    cout << "Invalid inputs: The values must be positive and the base cannot "
            "be 1."
         << endl;
  }
  return 1; // Return 1 as a fallback value
}

// Function for calculating the natural logarithm of a number (base e)
double natural_logarithmic(double a) {
  double e = 2.71828;
  if (a > 0) {
    return log(a) / log(e);
  } else {
    cout << "Invalid input: The value must be positive." << endl;
  }
  return 1; // Return 1 as a fallback value
}

// Function for calculating arcsine (inverse sine) of a value
double arcsine(double a) {
  if (a <= 1 && a >= -1) {
    return 57.3 * asin(a); // Convert from radians to degrees
  } else {
    cout << "Invalid input: arcsine is defined only for values in the range "
            "[-1, 1]."
         << endl;
  }
  return 1; // Return 1 as a fallback value
}

// Function for calculating arccosine (inverse cosine) of a value
double arccosine(double a) {
  if (a <= 1 && a >= -1) {
    return 57.3 * acos(a); // Convert from radians to degrees
  } else {
    cout << "Invalid input: arccosine is defined only for values in the range "
            "[-1, 1]."
         << endl;
  }
  return 1; // Return 1 as a fallback value
}

// Function for calculating arctangent (inverse tangent) of a value
double arctangent(double a) {
  return 57.3 * atan(a); // Convert from radians to degrees
}
